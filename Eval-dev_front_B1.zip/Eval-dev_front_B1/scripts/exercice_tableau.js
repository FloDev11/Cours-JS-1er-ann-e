var fruits_disponibles = [ 'Pommes', 'Poires', 'Bananes', 'Oranges', 'Papayes', 'Kiwi']


