const motsPossibles = [
    'digital',
    'informatique',
    'javascript'
];
let input_lettre_saisie = document.getElementById('lettre_saisie')


initializePartie()
input_lettre_saisie.focus()

// ...
// Peaufinage : Faire en sorte de cacher le bouton par défaut, et l'afficher si l'input est rempli uniquement;

function initializePartie(){
    console.log('initializePartie todo');
    /*
        random select mot parmi les mots possible,

        préparation zone de jeu
    */
}

function handleNewLettre(){
    // Todo : au click sur bouton, ou quand la touche entrée est tapée quand l'utilisateur est dans l'input,
    /* - detect si la lettre saisie a déjà été saisie,
            Si déjà saisie : afficher un message à l'utilisateur        
            Si pas le cas: 
                vérifier si la lettre est présente à un ou plusieurs endroit du mot,
                    Si présent: Afficher les lettres 
                    Si non, mettre à jour l'image
                    ... + detect si partie terminée, 
    */
}